export { getAdmin } from './firebase/admin';
export { getAdmin as dbAdmin } from './firebase/admin';